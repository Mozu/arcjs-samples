module.exports = {
  
  'embedded.commerce.orders.createFromCart.before': {
      actionName: 'embedded.commerce.orders.createFromCart.before',
      customFunction: require('./domains/commerce.orders/embedded.commerce.orders.createFromCart.before')
  }
};
